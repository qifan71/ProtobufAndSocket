#! /bin/sh

curl -O https://storage.googleapis.com/protobuf_opensource_benchmark_data/datasets.tar.gz
tar -zvxf datasets.tar.gz

