﻿namespace Nuxleus.WebService {
    public enum RequestType {
        PUT,
        POST,
        GET,
        DELETE
    }
}
